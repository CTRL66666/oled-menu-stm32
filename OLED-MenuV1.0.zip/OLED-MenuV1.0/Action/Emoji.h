/* ---------------- Emoji.h ---------------- */

#ifndef __Emoji_H
#define __Emoji_H

void Emoji_KeyAction(uint8_t Event);
void Emoji_Enter(void);
void Emoji_Display(void);	//
void Emoji_Exit(void);
void Show_Emoji(void);
#endif