/* ---------------- TIMESET.c ---------------- */
/* ---------------- ʱ������ҳ,��һ�з�ɫ��ʾʱ,ʹ�ñ�����������ֵ,��OK��ȷ�� ---------------- */
#include "stm32f10x.h"
#include "Image.h"
#include <string.h>
#include "OLED.h"
#include "Animation.h"
#include "MyTimer.h"
#include "delay.h"
#include "Key.h"
#include "Image.h"
#include "TIMESET.h"
#include "MyRTC.h"
#include "Action.h"
typedef enum
{
	TIMESET_SWITCH,
	TIMESET_SETTIME,
	TIMESET_PAUSE,
	TIMESET_OVER
}TIMESET_STATE;
static TIMESET_STATE STATE=TIMESET_SWITCH;

TimeElement TimeArray[6]=
{
	{
		.Inx=0,
		.Value=&MyRTC_Time[0],
		.Str="��",	//������д����
	},
	
	{
		.Inx=1,
		.Value=&MyRTC_Time[1],
		.Str="��",	//������д����
	},
	{
		.Inx=2,
		.Value=&MyRTC_Time[2],
		.Str="��",	//������д����
	},
	{
		.Inx=3,
		.Value=&MyRTC_Time[3],
		.Str="ʱ",	//������д����
	},
	{
		.Inx=4,
		.Value=&MyRTC_Time[4],
		.Str="��",	//������д����
	},
	{
		.Inx=5,
		.Value=&MyRTC_Time[5],
		.Str="��",	//������д����	
	}
};

Contorller controller=	//��ƫ��=����ƫ��+ָ��ƫ�� :	ָ����Ԫ��λ�õ�ƫ��,����ƫ�Ƶ�λΪ16��
{
	.BaseOffset=0,
	.PointerOffset=0,
	.ElementHeight=16,
	.OffsetLine=0,
};


static ElementOffset LineOffset;

int8_t BaseOffsetTemp=0;

void LineOffset_Reset(void)
{
	  
	LineOffset.current_input=0;
	LineOffset.target_output=0;
	controller.BaseOffset+=BaseOffsetTemp;
	controller.OffsetLine=0;
	BaseOffsetTemp=0;
	/*
	//������
	if(controller.PointerOffset==3)
	{
		controller.BaseOffset++;
	}
	else if(controller.PointerOffset==0)
	{
		controller.BaseOffset--;
	}
	*/
	
	
	//ACTION_Exit();
}

/**
  * @brief  ���ν���Ӧ�õ��ñ�����
  * @param  ��
  * @retval ��
  */
void TIMESET_Enter()
{
	int8_t i;
	
	OLED_ClearBuf();
	ActionKey_Init(TIMESET_KeyAction);
	ActionDisplay_Init(TIMESET_ShowUI);
	TIMESET_ShowUI();
	ElementOffset_Init(&LineOffset,0);
	Timer_SetPrescaler(100*menuOptions.SystemClock/72);
	TaskTimer.UpdateTask = 1;
	
	
}

/**
  * @brief  Ӧ�õİ�������,,����״̬��
  * @param  ��
  * @retval ��
  */
void TIMESET_KeyAction(uint8_t Event)
{
	switch(STATE)
	{
		case TIMESET_SWITCH:
			
			if (Event == 1)//��ת
			{
				if(controller.PointerOffset>0) {controller.PointerOffset--;}

				else if(controller.BaseOffset+BaseOffsetTemp>0) 
				{
					ElementOffset_SetTarget(&LineOffset,controller.OffsetLine+=16,LineOffset_Reset);
					BaseOffsetTemp-=1;
				}
			
			
			}
			else if(Event == 2)
			{
				if(controller.PointerOffset<3) {controller.PointerOffset++;}
				else if(controller.BaseOffset+BaseOffsetTemp<2) 
				{
					ElementOffset_SetTarget(&LineOffset,controller.OffsetLine-=16,LineOffset_Reset);
					BaseOffsetTemp+=1;
				}
			}
			else if (Event == 3)
			{
				ACTION_Exit();
			}
			else if (Event == 4)
			{
				STATE=TIMESET_SETTIME;
				TIMESET_ShowUI();

			}
			break;
		case TIMESET_SETTIME:
			
			if (Event == 1)
			{
				(*TimeArray[controller.BaseOffset+controller.PointerOffset].Value)--;
			}
			else if (Event == 2)
			{
				(*TimeArray[controller.BaseOffset+controller.PointerOffset].Value)++;
			}
			else if (Event == 3 )
			{
				STATE=TIMESET_SWITCH;
				ACTION_Exit();
				
			}
			else if (Event == 4)
			{
				STATE=TIMESET_SWITCH;
				MyRTC_SetTime();
			}
	}
}

/**
  * @brief  ��ʱ�����õĽ���UI
  * @param  ��
  * @retval ��
  */

void TIMESET_ShowUI(void)
{
	OLED_ClearBuf();
	if(STATE==TIMESET_SWITCH) MyRTC_ReadTime();
	int8_t min=(controller.BaseOffset>0)?-controller.BaseOffset:0;
	int8_t max=4-min+BaseOffsetTemp;
	for(int8_t i=min;i<max;i++)
	{
		OLED_Printf((int8_t)(LineOffset.current_input/10)+16*i,0,16,16,0,"%s:%2d",(TimeArray[controller.BaseOffset+i].Str),*(TimeArray[controller.BaseOffset+i].Value));
	}
	OLED_ShowString(16*controller.PointerOffset,100,"<-",0);
	if(STATE==TIMESET_SETTIME) OLED_ReverseArea(16*controller.PointerOffset,0,16,128);
	ElementOffset_Update(&LineOffset);
}


