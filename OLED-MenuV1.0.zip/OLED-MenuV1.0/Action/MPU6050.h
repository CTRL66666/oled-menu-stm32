/* ---------------- MPU6050.h ---------------- */

#ifndef __MPU6050_H
#define __MPU6050_H

void MPU6050_KeyAction(uint8_t Event);
void MPU6050_Enter(void);
void MPU6050_Display(void);	//

void Show_MPU6050(void);
void MPU6050_Exit(void);

#endif