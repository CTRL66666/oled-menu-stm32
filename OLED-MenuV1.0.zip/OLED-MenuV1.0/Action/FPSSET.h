/* ---------------- FPSSET.h ---------------- */

#ifndef __FPSSET_H
#define __FPSSET_H
void FPSSET_Enter();
void FPSSET_KeyAction(uint8_t Event);


#endif