/* ---------------- Snake.h ---------------- */
#ifndef __DINOWAR_H
#define __DINOWAR_H

void DinoWar_Enter(void);
void DinoWar_KeyAction(uint8_t event);
void DinoWar_Display(void);
void DinoWar_Exit();
#endif