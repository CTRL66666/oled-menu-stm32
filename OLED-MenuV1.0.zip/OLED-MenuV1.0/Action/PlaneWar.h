/* ---------------- PlaneWar.h ---------------- */

#ifndef __PlaneWar_H
#define __PlaneWar_H

void PlaneWar_KeyAction(uint8_t event);
void PlaneWar_Enter(void);
void PlaneWar_Display(void);	//
void PlaneWar_Exit(void);
#endif