/* ---------------- SystemSET.c ---------------- */
/* ---------------- ϵͳ����ҳ,�ṩ������Ƶ,�鿴��Ϣ�ȹ��� ---------------- */
#include "stm32f10x.h"
#include "Image.h"
#include <string.h>
#include "OLED.h"
#include "Animation.h"
#include "MyTimer.h"
#include "delay.h"
#include "Key.h"
#include "Image.h"
#include "Action.h"
#include <stdlib.h>		//�����ڴ�
#include "SystemSET.h"
#include "SystemSET_Pages.h"

typedef enum 
{
	SYSTEMSET_HOMEPAGE,	//��ҳ
	SYSTEMSET_CHILDPAGE,	//��ҳ
	SYSTEMSET_THIRDPAGE,	//����ҳ
	SYSTEMSET_OVER		//����ҳ
}SYSTEMSET_STATE;

static SYSTEMSET_STATE STATE=SYSTEMSET_HOMEPAGE;

SystemElement HomePage[5]=
{
	{
		.Inx=0,
		.Value=0,
		.Str="��Դ����",	//������д����
		.ChildPage=PowerPage,
		.Icon=Icon_Batterry,
	},
	
	{
		.Inx=1,
		.Value=0,
		.Str="��������",	//������д����
		.Action=NVIC_SystemReset,
		.Icon=Icon_Restart,
	},
	{
		.Inx=2,
		.Value=0,
		.Str="��ʾ����",	//������д����
		.ChildPage=DisplayPage,
		.Icon=Icon_Display,
	},
	{
		.Inx=3,
		.Value=0,
		.Str="�����豸",	//������д����
		.ChildPage=AboutPage,
		.Icon=Icon_About,
	},
	{
		.Inx=255,
		.Value=0,
		.Str="��ʱ����",	//������д����
		.Icon=Icon_Clock,
	}
};

PointerContorller Pointer=
{
	.CurrentPage=HomePage,//ָ���ʼ��ָ����ҳ
	.BaseOffset=0,
	.PointerOffset=0,
	.ReversePos=255,	//255��������ɫ������,Ĭ�ϲ���ɫ
};
	
/**
  * @brief  ���ν���Ӧ�õ��ñ�����
  * @param  ��
  * @retval ��
  */
void SystemSET_Enter()
{
	int8_t i,column;
	
	for(u8 i=3;i<12;i++)
	{
		column+=i;
		OLED_ClearBufArea(0,127-column,64,column);
		OLED_OffsetUpdate(0,-i);	//���ٶ�
	}
	OLED_ClearBuf();
	SystemSET_ShowCurPage();
	ActionKey_Init(SystemSET_KeyAction);
}

/**
  * @brief  Ӧ�õİ�������,,����״̬��
  * @param  ��
  * @retval ��
  */
void SystemSET_KeyAction(uint8_t Event)
{
	switch(STATE)
	{
		case SYSTEMSET_HOMEPAGE:
			
			if (Event == 1)//��ת
			{
				
				if(Pointer.PointerOffset>0) {Pointer.PointerOffset--;}

				else if(Pointer.BaseOffset>0) {Pointer.BaseOffset--;}
				
				SystemSET_ShowCurPage();
				
			}
			else if(Event == 2)
			{
				
				if(Pointer.PointerOffset<2) {Pointer.PointerOffset++;}
				else if(Pointer.CurrentPage[Pointer.BaseOffset+2].Inx != 255) {Pointer.BaseOffset++;}
				SystemSET_ShowCurPage();
				
			}
			else if (Event == 3)
			{
				
				ACTION_Exit();
			}
			else if (Event == 4)
			{
				if(Pointer.CurrentPage[Pointer.BaseOffset+Pointer.PointerOffset].ChildPage)	//���ָ��ָ��ѡ�������ҳ
				{
					Pointer.CurrentPage=Pointer.CurrentPage[Pointer.BaseOffset+Pointer.PointerOffset].ChildPage;
					Pointer.ChildContorller = (PointerContorller *)malloc(sizeof(PointerContorller));
					Pointer.ChildContorller->BaseOffset=Pointer.BaseOffset;
					Pointer.ChildContorller->PointerOffset=Pointer.PointerOffset;
					Pointer.BaseOffset=0;
					Pointer.PointerOffset=0;
					STATE=SYSTEMSET_CHILDPAGE;
					
					if(Pointer.ChildContorller->BaseOffset+Pointer.ChildContorller->PointerOffset==0)	//�������Դ����ҳ,����0
					{
						if(menuOptions.SystemClock==72){Pointer.ReversePos=0;}
						else if(menuOptions.SystemClock==40){Pointer.ReversePos=1;}
						else if(menuOptions.SystemClock==24){Pointer.ReversePos=2;}
						else if(menuOptions.SystemClock==8){Pointer.ReversePos=3;}
							
					}
				}
				else if (Pointer.CurrentPage[Pointer.BaseOffset+Pointer.PointerOffset].Action)
				{
					Pointer.CurrentPage[Pointer.BaseOffset+Pointer.PointerOffset].Action();
				}
				SystemSET_ShowCurPage();
			}
			break;
			
		case SYSTEMSET_CHILDPAGE:
			
			if (Event == 1)
			{
				if(Pointer.PointerOffset>0) {Pointer.PointerOffset--;}

				else if(Pointer.BaseOffset>0) {Pointer.BaseOffset--;}
				
				SystemSET_ShowCurPage();
			}
			else if (Event == 2)
			{
				if(Pointer.PointerOffset<2) {Pointer.PointerOffset++;}
				else if(Pointer.CurrentPage[Pointer.BaseOffset+2].Inx != 255) {Pointer.BaseOffset++;}
				SystemSET_ShowCurPage();
			}
			else if (Event == 3 )
			{
				u8 column;
				for(u8 i=1;i<25;i++)
				{
					column+=i;
					OLED_OffsetUpdate(0,5);	//���ٶ�
					OLED_ClearBufArea(0,0,64,column);
				}
				Pointer.CurrentPage=HomePage;
				Pointer.BaseOffset=Pointer.ChildContorller->BaseOffset;
				Pointer.PointerOffset=Pointer.ChildContorller->PointerOffset;
				free(Pointer.ChildContorller);
				STATE=SYSTEMSET_HOMEPAGE;
				Pointer.ReversePos=255;	//��ɫ����
				SystemSET_ShowCurPage();
			}
			else if (Event == 4)
			{
				if(Pointer.CurrentPage[Pointer.BaseOffset+Pointer.PointerOffset].ChildPage)	//���ָ��ָ��ѡ�������ҳ
				{
					Pointer.CurrentPage=Pointer.CurrentPage[Pointer.BaseOffset+Pointer.PointerOffset].ChildPage;
					STATE=SYSTEMSET_THIRDPAGE;
					
				}
				else if (Pointer.CurrentPage[Pointer.BaseOffset+Pointer.PointerOffset].Action)
				{
					Pointer.CurrentPage[Pointer.BaseOffset+Pointer.PointerOffset].Action();
				}
				SystemSET_ShowCurPage();
			}
	}
}

/**
  * @brief  ��ʾ��ǰ״̬��ҳ��
  * @param  ��
  * @retval ��
  */
void SystemSET_ShowCurPage(void)
{
	
	OLED_ClearBuf();
	
	for(u8 i=0;i<3;i++)
	{
		
		if((Pointer.CurrentPage[Pointer.BaseOffset+i].Value))
		{
			OLED_Printf(20*i+4,2,16,16,0,"%s%s",(Pointer.CurrentPage[Pointer.BaseOffset+i].Str),(Pointer.CurrentPage[Pointer.BaseOffset+i].Value));

		}
		else
		{
			if(Pointer.CurrentPage[Pointer.BaseOffset+i].Icon)
			{
				OLED_ShowImage(20*i+4,0,16,16,Pointer.CurrentPage[Pointer.BaseOffset+i].Icon,1);
			}
			if(Pointer.CurrentPage[Pointer.BaseOffset+i].Str)	OLED_Printf(20*i+4,18,18,18,0,"%s",(Pointer.CurrentPage[Pointer.BaseOffset+i].Str));
			
		}
	}

	OLED_ShowString(20*Pointer.PointerOffset+4,108,"<-",0);
	if(Pointer.ReversePos<255 && (Pointer.ReversePos-Pointer.BaseOffset)>=0) 
	{
		OLED_ReverseArea(20*(Pointer.ReversePos-Pointer.BaseOffset)+4,0,20,128);
	}
	OLED_Update();

}



void SystemSET_SysClockConfig_Max()
{
	SystemInit();
	menuOptions.SystemClock=72;
	Pointer.ReversePos=0;
}


void SystemSET_SysClockConfig_Medium()
{
	SystemSET_SysClockConfig_HSI();
	uint32_t t = 0;
	/*
	// ��� HSI �Ƿ��Ѿ�����
    if (RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET)
    {
        RCC_HSICmd(ENABLE);
        
        while (RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET && ++t < 0x2000)
        {
            if (t >= 0x2000) 
            {
                break;
            }
        }
    }
	RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);    
	SystemCoreClock = 8000000;
	SystemCoreClockUpdate();	

	*/
	RCC_HSEConfig(RCC_HSE_ON);  
	t = 0;
    while (RCC_GetFlagStatus(RCC_FLAG_HSERDY) == RESET && t++ < 0x2000)
    {
        if (t >= 0x2000) 
        {
            // HSE ����ʧ�ܣ��ɷ��ش���򱣳� HSI
            return;
        }
    }
	
	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_5);
	t = 0;
	FLASH_SetLatency(FLASH_Latency_2);
	RCC_PLLCmd(ENABLE);
	while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET && ++t < 0x8000)
	{
		if (t >= 0x8000) 
		{
			break;
		}
	}
	RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
	
	t = 0;
	while (++t < 0x1000)
	{
		if (t >= 0x1000) 
		{
			break;
		}
	}
	RCC_HSICmd(DISABLE);
	menuOptions.SystemClock=40;
	SystemCoreClock = 40000000;
	SystemCoreClockUpdate();
	Pointer.ReversePos=1;
	
	
}


void SystemSET_SysClockConfig_Low()
{
	uint32_t t = 0;
	// ��� HSI �Ƿ��Ѿ�����
    if (RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET)
    {
        RCC_HSICmd(ENABLE);
        
        while (RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET && ++t < 0x2000)
        {
            if (t >= 0x2000) 
            {
                break;
            }
        }
    }
	RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);    
	SystemCoreClock = 8000000;
	SystemCoreClockUpdate();	

	SystemSET_SysClockConfig_HSI();
	
	RCC_HSEConfig(RCC_HSE_ON);  
	t = 0;
    while (RCC_GetFlagStatus(RCC_FLAG_HSERDY) == RESET && t++ < 0x4000)
    {
        if (t >= 0x4000) 
        {
            // HSE ����ʧ�ܣ��ɷ��ش���򱣳� HSI
            return;
        }
    }
	
	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_3);
	t = 0;
	FLASH_SetLatency(FLASH_Latency_2);
	RCC_PLLCmd(ENABLE);
	while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET && ++t < 0x8000)
	{
		if (t >= 0x8000) 
		{
			break;
		}
	}
	RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
	
	t = 0;
	while (++t < 0x1000)
	{
		if (t >= 0x1000) 
		{
			break;
		}
	}
	RCC_HSICmd(DISABLE);
	menuOptions.SystemClock=24;
	SystemCoreClock = 24000000;
	SystemCoreClockUpdate();
	Pointer.ReversePos=2;
	
		
}

void SystemSET_SysClockConfig_HSI()
{
	RCC_HSICmd(ENABLE);
	uint32_t t = 0;
	while (RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET && ++t < 0x1000)
	{
		if (t >= 0x1000) 
		{
			break;
		}
	}
	RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);    
	SystemCoreClock = 8000000;
	SystemCoreClockUpdate();	

	menuOptions.SystemClock=8;
	RCC_PLLCmd(DISABLE);
	RCC_HSEConfig(RCC_HSE_OFF); 
	Pointer.ReversePos=3;

}

void Display_Reverse()
{
	if(OledOptions.DisplayReverse)
	{
		OledOptions.DisplayReverse=0;
	}
	else OledOptions.DisplayReverse=1;
	SystemSET_ShowCurPage();
}