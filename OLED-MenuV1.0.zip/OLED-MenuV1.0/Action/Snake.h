/* ---------------- Snake.h ---------------- */

#ifndef __Snake_H
#define __Snake_H

void SNAKE_KeyAction(uint8_t Event);
void SNAKE_Enter(void);
void SNAKE_Display(void);	//
void SNAKE_Exit(void);
#endif