/* ---------------- Snake.c ---------------- */
#include "stm32f10x.h"
#include "Image.h"
#include <string.h>
#include "OLED.h"
#include "Animation.h"
#include "MyTimer.h"
#include "Snake.h"
#include "Key.h"
#include "Delay.h"
#include "Action.h"
/*
��������ʱ��ת:EVENT 1
������˳ʱ��ת:EVENT 2
�����ж�1:EVENT 3
�����ж�2:EVENT 4
*/
/* �����¼�ֵ */
#define ENC_CW      1
#define ENC_CCW     2
#define KEY_BACK    3
#define KEY_OK      4


/* ��Ϸ���� */
#define MAP_W       128
#define MAP_H       64
#define DOT_SIZE    6              // 4��4 ����һ��
#define GRID_W      (MAP_W/DOT_SIZE)
#define GRID_H      (MAP_H/DOT_SIZE)
#define MAX_SNAKE   40

typedef enum {
    SNAKE_READY,
    SNAKE_PLAYING,
    SNAKE_PAUSE,
    SNAKE_OVER
} SNAKE_STATE;

/*---------- ȫ�ֱ��� ----------*/
static SNAKE_STATE state = SNAKE_READY;

static struct {
    uint8_t x,y;
} snake[MAX_SNAKE];
static uint8_t snakeLen = 3;
static int8_t  dirX = 1, dirY = 0;   // ��ǰ����
static uint8_t foodX, foodY;
static uint8_t tickCnt = 0;          // 100 ms ��һ�Σ�������ͼӼ�����
static uint8_t rng_seed = 0x5A;

static uint8_t rand(void)
{
    rng_seed = (rng_seed << 1) | ((rng_seed >> 7) & 1);
    rng_seed ^= 0x1B;
    return rng_seed;
}



/*---------- �ڲ����� ----------*/
static void draw_block(uint8_t gx, uint8_t gy, uint8_t fill)
{
    uint8_t px = gx * DOT_SIZE;
    uint8_t py = gy * DOT_SIZE;
    OLED_FillRect(py, px, DOT_SIZE, DOT_SIZE, fill);
}
static void place_food(void)
{
    do {
        foodX = rand() % GRID_W;
        foodY = rand() % GRID_H;
    } while (draw_block(foodX, foodY, 2), 0); // 2=ֻ��⣬����
}
static void snake_init(void)
{
    snakeLen = 3;
    for (uint8_t i = 0; i < snakeLen; i++) {
        snake[i].x = GRID_W/2 - i;
        snake[i].y = GRID_H/2;
    }
    dirX = 1; dirY = 0;
    place_food();
}
static void snake_move(void)
{
    /* ������ͷ��������ǽ */
    int16_t nx = (int16_t)snake[0].x + dirX;
    int16_t ny = (int16_t)snake[0].y + dirY;

    /* ��ǽ���� */
    if (nx < 0) nx = GRID_W - 1;
    else if (nx >= GRID_W) nx = 0;
    if (ny < 0) ny = GRID_H - 1;
    else if (ny >= GRID_H) ny = 0;

    /* ײ�Լ����� */
    for (uint8_t i = 0; i < snakeLen; i++)
        if (snake[i].x == (uint8_t)nx && snake[i].y == (uint8_t)ny)
        { state = SNAKE_OVER; return; }

    /* ǰ������ */
    for (uint8_t i = snakeLen; i > 0; i--) snake[i] = snake[i-1];
    snake[0].x = (uint8_t)nx;
    snake[0].y = (uint8_t)ny;

    /* ��ʳ�� */
    if (snake[0].x == foodX && snake[0].y == foodY) {
        if (snakeLen < MAX_SNAKE) snakeLen++;
        place_food();
    }
}
/**
  * @brief  ����ӿ�,���ν���Ӧ�õ��ñ�����
  * @param  ��
  * @retval ��
  */
void SNAKE_Enter(void)
{
	for(u8 i=3;i<12;i++)
	{
		OLED_OffsetUpdate(i,0);	//���ٶ�
	}
	OLED_ClearBuf();
    state = SNAKE_READY;
	ActionDisplay_Init(SNAKE_Display);
	ActionKey_Init(SNAKE_KeyAction);
    snake_init();
    TaskTimer.UpdateTask = 1;
}

/**
  * @brief  Ӧ�õİ�������,,����״̬��
  * @param  ��
  * @retval ��
  */
void SNAKE_KeyAction(uint8_t event)
{
    switch (state) {
    case SNAKE_READY:
        if (event == KEY_OK) { state = SNAKE_PLAYING; }
		else if (event == KEY_BACK) 
		{
			ACTION_Exit();
		}
        break;

	case SNAKE_PLAYING:
		if (event == ENC_CW) {              // ˳ʱ�� �� �ߡ��ҡ�ת
			if (dirX == 1)  { dirX = 0; dirY = 1; }   // ԭ�ҡ���
			else if (dirY == 1) { dirX = -1; dirY = 0; } // ԭ�¡���
			else if (dirX == -1){ dirX = 0; dirY = -1;} // ԭ�����
			else if (dirY == -1){ dirX = 1; dirY = 0; } // ԭ�ϡ���
		}
		else if (event == ENC_CCW) {        // ��ʱ�� �� �ߡ���ת
			if (dirX == 1)  { dirX = 0; dirY = -1; }  // ԭ�ҡ���
			else if (dirY == -1){ dirX = -1; dirY = 0;} // ԭ�ϡ���
			else if (dirX == -1){ dirX = 0; dirY = 1; } // ԭ�����
			else if (dirY == 1) { dirX = 1; dirY = 0; } // ԭ�¡���
		}
		else if (event == KEY_OK || event == KEY_BACK) {
			state = SNAKE_PAUSE;   // ��������������ͣ
		}
		break;

    case SNAKE_PAUSE:
        if (event == KEY_OK) { state = SNAKE_PLAYING; }
		else if (event == KEY_BACK) 
		{
			ActionKey_Free(SNAKE_KeyAction);
			ACTION_Exit();
		}
        break;

    case SNAKE_OVER:
        if (event == KEY_OK) { snake_init(); state = SNAKE_READY; }
		else if (event == KEY_BACK) 
		{
			ActionKey_Free(SNAKE_KeyAction);
			ACTION_Exit();
		}
        break;
    }
}
/**
  * @brief  Ӧ�õ���ʾ�߼�,�ɶ�ʱ������
  * @param  ��
  * @retval ��
  */
void SNAKE_Display(void)
{
    
	OLED_ClearBuf();               // ˫������ 0
    switch (state) {
    case SNAKE_READY:
        OLED_ShowString(30, 20, "SNAKE READY", 1);
        OLED_ShowString(10, 40, "OK:START", 1);
        break;

    case SNAKE_PLAYING:
		
        /* ��ʳ�� */
        draw_block(foodX, foodY, 0);
        /* ���� */
        for (uint8_t i = 0; i < snakeLen; i++)
            draw_block(snake[i].x, snake[i].y, 0);
        /* ÿ 100 ms ��һ�� */
        snake_move();
        break;

    case SNAKE_PAUSE:
        OLED_ShowString(30, 25, "PAUSE", 1);
        OLED_ShowString(10, 30, "OK:CONTINUE", 1);
        break;

    case SNAKE_OVER:
        OLED_ShowString(30, 25, "GAME OVER", 1);
        OLED_ShowNum(50, 40, snakeLen, 3,16,8,1);
        OLED_ShowString(0, 15, "OK:RESTART", 1);
        break;
    }

}
