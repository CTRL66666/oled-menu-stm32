/* ---------------- FlappyBird.h ---------------- */

#ifndef __FlappyBird_H
#define __FlappyBird_H

void FlappyBird_KeyAction(uint8_t Event);
void FlappyBird_Enter(void);
void FlappyBird_Display(void);	//
void FlappyBird_Exit(void);
#endif