/* ---------------- Emoji.c ---------------- */
/* ---------------- ��Ӧ�ò������� ---------------- */
#include "stm32f10x.h"
#include "Image.h"
#include <string.h>
#include "OLED.h"
#include "Animation.h"
#include "MyTimer.h"
#include "Emoji.h"
#include "Key.h"
#include "MyRTC.h"
#include "Emoji_Image.h"
#include "Delay.h"
#include "Action.h"
/*
��������ʱ��ת:EVENT 1
������˳ʱ��ת:EVENT 2
�����ж�1:EVENT 3
�����ж�2:EVENT 4
*/
/* �����¼�ֵ */
#define ENC_CCW     2
#define ENC_CW      1
#define KEY_OK      4
#define KEY_BACK    3

typedef enum {
    Emoji_READY,
} Emoji_STATE;

/*---------- ȫ�ֱ��� ----------*/
static Emoji_STATE state = Emoji_READY;


/*========== ����ӿ� ==========*/
void Emoji_Enter(void)
{
    state = Emoji_READY;
	ActionDisplay_Init(Emoji_Display);
	ActionKey_Init(Emoji_KeyAction);
	OLED_ClearBuf();
	Timer_SetPrescaler(5000*menuOptions.SystemClock/72);
    TaskTimer.UpdateTask = 1;
}

void Emoji_KeyAction(uint8_t event)
{
    switch (state) 
	{
		case Emoji_READY:
			if (event == KEY_OK) {  }
			else if (event == KEY_BACK) { Emoji_Exit(); }
			break;
    }
}

void Emoji_Display(void)
{
    
	OLED_ClearBuf();               // ˫������ 0
    switch (state) {
    case Emoji_READY:
        Show_Emoji();
        break;

    }
}

void Show_Emoji(void)
{
/*����*/
	for(uint8_t i=0;i<3;i++)
	{
		OLED_Clear();
		OLED_ShowImage(10+i,30,16,16,Eyebrow[0],1);//��üë
		OLED_ShowImage(10+i,82,16,16,Eyebrow[1],1);//��üë
		OLED_DrawEllipse(40,32,6,6-i,1);//����
		OLED_DrawEllipse(88,32,6,6-i,1);//����
		OLED_ShowImage(40,54,20,20,Mouth,1);
		OLED_Update();
		Delay_ms(50);
	}
	
	/*����*/
	for(uint8_t i=0;i<3;i++)
	{
		OLED_Clear();
		OLED_ShowImage(12-i,30,16,16,Eyebrow[0],1);//��üë
		OLED_ShowImage(12-i,82,16,16,Eyebrow[1],1);//��üë
		OLED_DrawEllipse(40,32,6,4+i,1);//����
		OLED_DrawEllipse(88,32,6,4+i,1);//����
		OLED_ShowImage(40,54,20,20,Mouth,1);
		OLED_Update();
		Delay_ms(50);	//*menuOptions.SystemClock/72
	}
}

void Emoji_Exit(void)
{
	Timer_SetPrescaler(720);
	ACTION_Exit();
	
}