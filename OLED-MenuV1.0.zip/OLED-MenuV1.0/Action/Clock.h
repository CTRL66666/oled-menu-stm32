/* ---------------- Clock.h ---------------- */

#ifndef __Clock_H
#define __Clock_H

void CLOCK_KeyAction(uint8_t Event);
void CLOCK_Enter(void);
void CLOCK_Display(void);	//
void CLOCK_Exit(void);
void Show_ClOCK(void);
void GPIO_LowPower_Config(void);
void System_ExitStopMode(void);
#endif